package lambdasinaction.chap9;

/**
 * Created by raoul-gabrielurma on 15/01/2014.
 */
public interface Drawable{
    public void draw();
}
