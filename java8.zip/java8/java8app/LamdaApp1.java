package java8app;

public class LamdaApp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		(param) -> System.out.println("One parameter: " + param);
		
	}

}
