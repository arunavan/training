package com.hcl.service;

import java.util.List;

import com.hcl.entity.Employee;

public interface EmployeeService {
	
	public abstract void saveEmployee(Employee employee);
	public abstract List<Employee>getEmployeeList();

}
