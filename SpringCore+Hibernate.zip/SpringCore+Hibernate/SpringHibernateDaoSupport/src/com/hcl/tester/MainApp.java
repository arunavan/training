package com.hcl.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.entity.Employee;
import com.hcl.service.EmployeeService;

public class MainApp {

	public static void main(String[] args) {
		
		ApplicationContext  context = new ClassPathXmlApplicationContext("Spring2.xml");
		
		EmployeeService service = (EmployeeService) context.getBean("employeeService");
		
		Employee employee = new Employee();
		employee.setEmployeeName("Rita");
		employee.setSalary(20000);
		
		service.saveEmployee(employee);
		System.out.println("Data persisted successfully");
		System.out.println("************************************");
		
		for(Employee emp: service.getEmployeeList()){
			System.out.println("Employee Id "+emp.getEmployeeId());
			System.out.println("Employee Name "+emp.getEmployeeName());
			System.out.println("Salary "+emp.getSalary());
		}

	}

}
