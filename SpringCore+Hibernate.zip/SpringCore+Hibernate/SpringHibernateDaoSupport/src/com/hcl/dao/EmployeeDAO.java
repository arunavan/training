package com.hcl.dao;

import java.util.List;

import com.hcl.entity.Employee;

public interface EmployeeDAO {
	
	public abstract void saveEmployee(Employee employee);
	public abstract List<Employee>getEmployeeList();

}
