package com.hcl.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.hcl.entity.Employee;
@Repository("employeeDAO")
public class EmployeeDAOImpl extends HibernateDaoSupport implements EmployeeDAO{
	
	

	@Override
	public void saveEmployee(Employee employee) {
		getHibernateTemplate().save(employee);
		
	}

	@Override
	public List<Employee> getEmployeeList() {
	
		return (List<Employee>) getHibernateTemplate().find("from Employee");
	}

}
