package com.hcl.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.hcl.entity.Employee;
@Repository("employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO{
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Override
	public void saveEmployee(Employee employee) {
		hibernateTemplate.save(employee);
		
	}

	@Override
	public List<Employee> getEmployeeList() {
	
		return (List<Employee>) hibernateTemplate.find("from Employee");
	}

}
