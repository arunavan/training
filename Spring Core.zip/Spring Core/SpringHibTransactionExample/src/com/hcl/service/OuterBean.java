package com.hcl.service;

import com.hcl.entity.User;

public interface OuterBean {

	void testRequired(User user);
	
	void testRequiresNew(User user);

}
