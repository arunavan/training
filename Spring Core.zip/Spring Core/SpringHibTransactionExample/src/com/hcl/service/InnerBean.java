package com.hcl.service;

public interface InnerBean {

	void testRequired(int age);
	
	void testRequiresNew(int age);
	
}
