package com.hcl.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.entity.User;
import com.hcl.service.OuterBean;

public class Main 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
    	OuterBean outerBean = (OuterBean) ctx.getBean("outerBeanImpl");
    	
    	User user = new User();
    	user.setUsername("Sam");
    	user.setAge(17);
    	
    	try{
    		outerBean.testRequired(user);
    	} catch(Exception e){
    		System.out.println("Handled exception for transaction rollback");
    		//e.printStackTrace();
    		
    	}
    	
    	outerBean.testRequiresNew(user);
    	
    }
}
