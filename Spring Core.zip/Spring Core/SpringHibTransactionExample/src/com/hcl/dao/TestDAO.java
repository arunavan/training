package com.hcl.dao;

import com.hcl.entity.User;

public interface TestDAO {

	void insertUser(User user);

}
