package com.hcl.dao;

import java.util.List;

import com.hcl.entity.Employee;

public interface EmployeeDao {
	
	public Integer addEmployee(Employee employee);
	public void updateEmployee(Integer employeeId, Double salary);
	public void deleteEmployee(Integer employeeId);
	public Employee getEmployeeById(Integer employeeId);
	public List<Employee>getAllEmployee();

}
