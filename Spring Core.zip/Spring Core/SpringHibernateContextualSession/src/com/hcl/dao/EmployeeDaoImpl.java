package com.hcl.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.entity.Employee;
@Repository
public class EmployeeDaoImpl  implements EmployeeDao{

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Integer addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		Integer id = (Integer)sessionFactory.getCurrentSession().save(employee);
		return id;
	}

	@Override
	public void updateEmployee(Integer employeeId, Double salary) {
		
		Employee employee = (Employee) sessionFactory.getCurrentSession().get(Employee.class, employeeId);
		if(employee!=null){
		employee.setSalary(salary);
		sessionFactory.getCurrentSession().update(employee);
		}
		
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		Employee employee = (Employee) sessionFactory.getCurrentSession().get(Employee.class, employeeId);
		if(employee!=null){
			sessionFactory.getCurrentSession().delete(employee);
		}
		
	}

	@Override
	public Employee getEmployeeById(Integer employeeId) {
		Employee employee=null;
		employee = (Employee) sessionFactory.getCurrentSession().get(Employee.class, employeeId);
		if(employee!=null){
			return employee;
		}
	
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		return sessionFactory.getCurrentSession().createCriteria(Employee.class).list();
		/*Query query = sessionFactory.getCurrentSession().createQuery("from Employee e");
		List<Employee> list = query.list();
		return list;*/
	}
	
	
	
}
