package com.hcl.service;

import java.util.List;

import com.hcl.entity.Employee;

public interface EmployeeService {
	
	public Integer addEmployee(Employee employee);
	public void updateEmployee(Integer employeeId, Double salary);
	public void deleteEmployee(Integer employeeId);
	public Employee getEmployeeById(Integer employeeId);
	public List<Employee>getAllEmployee();

}
