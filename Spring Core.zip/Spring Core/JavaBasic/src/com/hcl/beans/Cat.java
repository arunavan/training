package com.hcl.beans;

public class Cat extends Animal {

	@Override
	public String makeSound() {
		// TODO Auto-generated method stub
		return "Meow";
	}

}
