package com.hcl.beans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainTest {

	public static void main(String[] args) {
		/*Calendar cal = new GregorianCalendar(2015, 1, 1);
		Calendar now = new GregorianCalendar();
	    int res = now.get(Calendar.YEAR) - cal.get(Calendar.YEAR);
	    if ((cal.get(Calendar.MONTH) > now.get(Calendar.MONTH))
	        || (cal.get(Calendar.MONTH) == now.get(Calendar.MONTH) && cal.get(Calendar.DAY_OF_MONTH) > now
	            .get(Calendar.DAY_OF_MONTH))) {
	      res--;
	    }
	    System.out.println(res);
	  }*/
		
		String text = " 03-25-2000";
				Date date;
				try {
					date = new SimpleDateFormat("MM-dd-yyyy").parse(text);
					long age1 = System.currentTimeMillis() - 	date.getTime();
					int age=(int) (age1/(24*60*60*1000));
					System.out.println("Age "+age);

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
						
		
		
	}	
		

}
