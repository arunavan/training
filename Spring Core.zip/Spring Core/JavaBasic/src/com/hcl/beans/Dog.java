package com.hcl.beans;

public class Dog extends Animal{

	@Override
	public String makeSound() {
		// TODO Auto-generated method stub
		return "Woof";
	}

}
