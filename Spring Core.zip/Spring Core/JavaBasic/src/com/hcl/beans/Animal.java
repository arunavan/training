package com.hcl.beans;

public abstract class Animal {
	public abstract String makeSound();
}
