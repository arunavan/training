package com.hcl.beans;

public class Demo {

	public static void main(String[] args) {
		AnimalFactory animalFactory = new AnimalFactory();
		
		Animal a1 = animalFactory.getAnimal("dog");
		System.out.println("a1 sound: " + a1.makeSound());

	}
}
