package com.hcl.model;

public interface Animal {
   public void makeSound();
}
