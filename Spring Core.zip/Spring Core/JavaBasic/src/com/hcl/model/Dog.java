package com.hcl.model;

public class Dog implements Animal {
	
	public void makeSound(){
		System.out.println("Woof");  
		
	}

}
