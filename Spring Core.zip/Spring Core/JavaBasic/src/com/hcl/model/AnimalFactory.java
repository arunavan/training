package com.hcl.model;

public class AnimalFactory {

	private Animal animal;
	
	
	public AnimalFactory(){
		
	}
	
	public AnimalFactory(Animal animal){
		this.animal=animal;
	}
	/*public Animal getAnimal(String type){
		
		if("dog".equals(type)){
		return new Dog();
		}else{
			return new Cat();
		}
	}*/

	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}
	
	public void animalSound(){
		this.getAnimal().makeSound();
	}
	
}
