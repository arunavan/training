package com.hcl.model;

public class Demo {

	public static void main(String[] args) {
		
		AnimalFactory factory = new AnimalFactory();
		Dog dog = new Dog();
		factory.setAnimal(dog);
		factory.animalSound();
		
		System.out.println("**********************");
		Cat cat = new Cat();
		factory.setAnimal(cat);
		factory.animalSound();
		
		Dog dog2 = new Dog();
		AnimalFactory factory2 = new AnimalFactory(dog2);
		factory2.animalSound();
		
		

	}

}
