package com.hcl.model;

public class Cat implements Animal {
	
	public void makeSound(){
		System.out.println("Meow");
	}

}
