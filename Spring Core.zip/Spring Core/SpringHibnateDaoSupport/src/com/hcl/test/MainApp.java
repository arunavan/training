package com.hcl.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.entity.Employee;
import com.hcl.service.EmployeeService;

public class MainApp {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
		EmployeeService service = (EmployeeService)context.getBean("employeeService");
		
		Employee employee = new Employee();
		employee.setEmployeeName("Harish");
		employee.setSalary(50000.00);
		
		//Integer id =service.addEmployee(employee);
		//System.out.println("Data persisted successfully with id = "+id);
		
		//service.updateEmployee(100, 75000.00);
		//System.out.println("Data updated successfully");
		
		//Employee emp = service.getEmployeeById(100);
		//System.out.println(emp.getEmployeeId()+"     "+emp.getEmployeeName()+"     "+emp.getSalary());
		
		
		List<Employee> empList=  service.getAllEmployee();
		System.out.println("Employee List\n");
		for (Employee emp : empList) {
			System.out.println(emp.getEmployeeId()+"     "+emp.getEmployeeName()+"     "+emp.getSalary());
		}

	}

}
