package com.hcl.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.hcl.entity.Employee;
@Repository
public class EmployeeDaoImpl  extends HibernateDaoSupport implements EmployeeDao{

	@Autowired //constructor injection
	public EmployeeDaoImpl(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
	}
	
	
	@Override
	public Integer addEmployee(Employee employee) {
		
		Integer id = (Integer) getHibernateTemplate().save(employee);
		return id;
		
	}

	@Override
	public void updateEmployee(Integer employeeId, Double salary) {
	Employee employee	=getHibernateTemplate().get(Employee.class, employeeId);
	if(employee!=null){
		employee.setSalary(salary);
		getHibernateTemplate().update(employee);
		
	}
	
		
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		Employee employee	=getHibernateTemplate().get(Employee.class, employeeId);
		if(employee!=null){
			getHibernateTemplate().delete(employee);
		}
		
	}

	@Override
	public Employee getEmployeeById(Integer employeeId) {
		Employee employee=null;
		employee	=getHibernateTemplate().get(Employee.class, employeeId);
		if(employee!=null){
			return employee;
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		return getHibernateTemplate().loadAll(Employee.class);
	}

}
