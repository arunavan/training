package com.hcl.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Scholar implements BeanNameAware, BeanFactoryAware, ApplicationContextAware, BeanPostProcessor,InitializingBean,DisposableBean{

	private Integer scholarId;
	private String scholarName;
	public Integer getScholarId() {
		return scholarId;
	}
	public void setScholarId(Integer scholarId) {
		this.scholarId = scholarId;
	}
	public String getScholarName() {
		return scholarName;
	}
	public void setScholarName(String scholarName) {
		this.scholarName = scholarName;
	}
	@Override
	public void setBeanName(String name) {
		System.out.println("Bean Name is "+name);
		
	}
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		System.out.println("Bean Factory "+beanFactory.getBean(Scholar.class));
		
	}
	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		System.out.println("Application Context  getId  "+context.getClass());
		System.out.println("Application Context "+context.containsBean("scholar"));
		
	}
	@Override
	public Object postProcessAfterInitialization(Object obj, String name) throws BeansException {
		System.out.println("postProcessAfterInitialization "+obj.getClass()+"     "+name);
		return obj;
	}
	@Override
	public Object postProcessBeforeInitialization(Object obj, String name) throws BeansException {
		System.out.println("postProcessBeforeInitialization  "+obj.getClass()+"     "+name);
		return obj;
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Init method is called");
		
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("Destroy method is called");
		
	}
	
	
}
