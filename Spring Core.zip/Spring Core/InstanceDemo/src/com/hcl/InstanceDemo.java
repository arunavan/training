package com.hcl;

import java.lang.annotation.AnnotationTypeMismatchException;

class A{
	
}

class B extends A{
	
}


class C extends A{
	
	
}

public class InstanceDemo {
	
	
	

	public static void main(String[] args) {
	
		A a = new A();
		B b = new B();
		C c = new C();
		
	boolean f = b instanceof A;
	boolean f1 =a instanceof B;
	
	System.out.println();
		

	}

}
