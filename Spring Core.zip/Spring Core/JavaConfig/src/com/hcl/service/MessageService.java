package com.hcl.service;

public interface MessageService {
	 
    boolean sendMessage(String msg, String rec);
}
