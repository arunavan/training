package com.hcl.service;

import org.springframework.stereotype.Service;

@Service(value="emailService")
public class EmailService implements MessageService{

	@Override
	public boolean sendMessage(String msg, String rec) {
		System.out.println("Email Sent to "+rec+ " with Message="+msg);
        return true;
	}

}
