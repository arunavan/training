package com.hcl.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.hcl.beans.MyApplication;
import com.hcl.service.EmailService;
import com.hcl.service.MessageService;

@Configuration
@ComponentScan(basePackages= {"com.hcl.beans","com.hcl.service"})
public class DIConfiguration {
	
	 /*@Bean
	    public MessageService getMessageService(){
	        return new EmailService();
	    }*/
	 
	 

}
