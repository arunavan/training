package com.hcl.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hcl.service.MessageService;

@Component
public class MyApplication {
	
	 private MessageService service;

	public MessageService getService() {
		return service;
	}

	@Autowired
	@Qualifier(value="twitterService")
	public void setService(MessageService service) {
		this.service = service;
	}
     
	 public boolean processMessage(String msg, String rec){
	        //some magic like validation, logging etc
	        return this.service.sendMessage(msg, rec);
	    }
	 

}
