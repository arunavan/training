package com.hcl.model;

public class Piano implements Instrument{

	@Override
	public void play() {
		System.out.println("TONG TONG TONG");
		
	}

}
