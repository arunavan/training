package com.hcl.model;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
//@ComponentScan(basePackages={"com.hcl.model"})
public class AppConfig {
	
	
	@Bean
	public Instrument getSitar(){
		return new Sitar();
	}
	
	@Bean
	public Instrument getGuitar(){
		return new Guitar();
	}
	
	
	@Bean
	public Instrument getPiano(){
		return new Piano();
	}
	
	@Bean(name={"performer"})
	@Scope("prototype")
	public Performer getPerformer(){
		Performer performer = new Performer();
		performer.setSong("sa re ga ma");
		performer.setInstrument(getSitar());
		
		return performer;
		
	}
	
	
	/*<bean id="sitar"  class="com.hcl.model.Sitar">
	<bean id="guitar"  class="com.hcl.model.Guitar">
	<bean id="piano"  class="com.hcl.model.Piano">
	
	
	<bean id="performer"  class="com.hcl.model.Performer">
	<property name="song"  value="sa re ga ma pa" />
	<property name="instrument"  ref="sitar">
	</bean>
*/
}
