package com.hcl.model;

public class Performer {

	private String song;
	
	private Instrument instrument;
	
	
	public String getSong() {
		return song;
	}
	public void setSong(String song) {
		this.song = song;
	}
	public Instrument getInstrument() {
		return instrument;
	}
	//@Autowired
	//@Qualifier(value="sitar")
	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}
	
	public void perform(){
		System.out.println("Singing......"+song);
	    instrument.play();
	}
	

}
