package com.hcl.model;

public class Sitar implements Instrument {

	@Override
	public void play() {
		System.out.println("HOOT HOOT HOOT");
		
	}

}
