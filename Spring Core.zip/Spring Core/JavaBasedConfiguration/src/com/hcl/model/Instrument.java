package com.hcl.model;

public interface Instrument {
	
	void play();

}
