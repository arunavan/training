package com.hcl.beans;

public interface Instrument {
	
	void play();

}
