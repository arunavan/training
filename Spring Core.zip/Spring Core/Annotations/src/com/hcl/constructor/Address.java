package com.hcl.constructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
interface i1{}
interface i2{}
interface i3 extends i1,i2{ }
@Component
public class Address {
	@Value("603103")
	private String pincode;
	@Value("Navlur")
	private String streetName;
	
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	
	
	
}
