package com.hcl.constructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component(value="scholar")
public class Scholar {
	
	@Value("101")
	private int scholarId;
	@Value("Priyanka")
	private String scholarName;

	private Address address;
	
	@Autowired
	public Scholar(Address address){
		this.address=address;
	}
	
	
	
	public void display(){
		System.out.println("Scholar Id: "+scholarId);
		System.out.println("Scholar Name"+scholarName);
		System.out.println("PinCode: "+address.getPincode());
		System.out.println("StreetName "+address.getStreetName());
	}

}
