package com.hcl.qualifier2;


