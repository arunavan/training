package com.hcl.qualifier2;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component

public class Sitar implements Instrument {

	@Override
	public void play() {
		System.out.println("HOOT HOOT HOOT");
		
	}

}
