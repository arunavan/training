package com.hcl.qualifier2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("performer")
public class Performer {
	@Value("Sa Re Ga Ma")
	private String song;
	
	private Instrument instrument;
	
	@Autowired
	
	public Performer(@Qualifier(value="guitar")Instrument instrument){
		this.instrument=instrument;
	}
	
	
	
	
	public void perform(){
		System.out.println("Singing......"+song);
	    instrument.play();
	}
	

}
