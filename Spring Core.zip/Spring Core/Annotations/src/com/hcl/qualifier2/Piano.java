package com.hcl.qualifier2;

import org.springframework.stereotype.Component;

@Component("piano")
public class Piano implements Instrument{

	@Override
	public void play() {
		System.out.println("TONG TONG TONG");
		
	}

}
