package com.hcl.qualifier2;

import org.springframework.stereotype.Component;

@Component(value="guitar")
public class Guitar implements Instrument{

	@Override
	public void play() {
		System.out.println("TING TING TING");
		
	}

}
