package com.hcl.qualifier2;

public interface Instrument {
	
	void play();

}
