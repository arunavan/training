package com.hcl.setter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component(value="scholar")
public class Scholar {
	
	@Value("101")
	private int scholarId;
	@Value("Priyanka")
	private String scholarName;

	private Address address;
	
	public Address getAddress() {
		return address;
	}
	
	@Autowired //byType
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getScholarId() {
		return scholarId;
	}
	public void setScholarId(int scholarId) {
		this.scholarId = scholarId;
	}
	public String getScholarName() {
		return scholarName;
	}
	public void setScholarName(String scholarName) {
		this.scholarName = scholarName;
	}
	
	public void display(){
		System.out.println("Scholar Id: "+getScholarId());
		System.out.println("Scholar Name"+getScholarName());
		System.out.println("PinCode: "+getAddress().getPincode());
		System.out.println("StreetName "+getAddress().getStreetName());
	}

}
