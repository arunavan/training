package com.hcl.test;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("addition")
@Scope("singleton")
public class Addition {
	@Value("100")
	private int x;
	@Value("100")
	private int y;
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public void sum(){
		System.out.println("Sum =  "+(x+y));
	}

	@PostConstruct
	public void myInit(){
		System.out.println("This is a init method");
	}
	
	@PreDestroy
	public void cleanUp(){
		System.out.println("This is a destroy method");
	}
	
	
}
