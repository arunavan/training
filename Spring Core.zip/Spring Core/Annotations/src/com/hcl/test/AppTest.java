package com.hcl.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTest {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("./com/hcl/test/Beans.xml");
		
		Calculate calculate= (Calculate)context.getBean("calculate");
		
		calculate.show();
	}

}
