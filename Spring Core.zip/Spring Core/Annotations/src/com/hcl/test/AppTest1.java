package com.hcl.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTest1 {

	public static void main(String[] args) {
	AbstractApplicationContext context = new ClassPathXmlApplicationContext("./com/hcl/test/Beans.xml");
	System.out.println("Initial Value");
	Addition addition1 = (Addition) context.getBean("addition");
	addition1.sum();
	
	addition1.setX(200);
	addition1.setY(200);
	System.out.println("After changes");
	addition1.sum();
	
	Addition addition2 = (Addition) context.getBean("addition");
	System.out.println("second reference will return the same object in singleton");
	addition2.sum();
	
	context.registerShutdownHook();

	}

}
