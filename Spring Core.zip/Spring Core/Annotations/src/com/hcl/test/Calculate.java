package com.hcl.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("calculate")
public class Calculate {
	
	@Autowired
	Addition addition1;
	@Autowired
	Addition addition2 ;
	
	
	public Addition getAddition1() {
		return addition1;
	}
	public void setAddition1(Addition addition1) {
		this.addition1 = addition1;
	}
	public Addition getAddition2() {
		return addition2;
	}
	public void setAddition2(Addition addition2) {
		this.addition2 = addition2;
	}
	
	public void show(){
		
		System.out.println("Addtion1 "+addition1.getX()+"   "+addition1.getY());
		System.out.println("Addition2 "+addition2.getX()+  "  "+addition2.getY() );
	}

}
