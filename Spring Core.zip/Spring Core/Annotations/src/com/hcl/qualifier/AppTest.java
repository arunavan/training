package com.hcl.qualifier;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTest {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("./com/hcl/qualifier/Beans.xml");
		Performer performer = context.getBean(Performer.class);
		
		performer.perform();
		
	}

}
