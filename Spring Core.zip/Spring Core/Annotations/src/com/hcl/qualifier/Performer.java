package com.hcl.qualifier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("performer")
public class Performer {
	@Value("Sa Re Ga Ma")
	private String song;
	
	@Autowired
	@Qualifier("piano")
	private Instrument instrument;
	
	
	public String getSong() {
		return song;
	}
	public void setSong(String song) {
		this.song = song;
	}
	public Instrument getInstrument() {
		return instrument;
	}
	//@Autowired
	//@Qualifier(value="sitar")
	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}
	
	public void perform(){
		System.out.println("Singing......"+song);
	    instrument.play();
	}
	

}
