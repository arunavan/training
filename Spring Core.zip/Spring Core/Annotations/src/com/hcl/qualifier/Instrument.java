package com.hcl.qualifier;

public interface Instrument {
	
	void play();

}
