package com.hcl.qualifier;

import org.springframework.stereotype.Component;

@Component("sitar")
public class Sitar implements Instrument {

	@Override
	public void play() {
		System.out.println("HOOT HOOT HOOT");
		
	}

}
