package com.hcl.service;

import java.io.IOException;
import java.sql.SQLDataException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.bean.Employee;
import com.hcl.dao.EmployeeDAO;

@Service(value="employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDAO;

	@Transactional(
			isolation = Isolation.READ_COMMITTED, readOnly= true, timeout=30, rollbackFor=SQLDataException.class)
	@Override
	public void addEmployee(Employee employee) {
		employeeDAO.addEmployee(employee);
		
	}

	@Transactional
	@Override
	public void updateEmployee(int employeeId, double salary) {
		employeeDAO.updateEmployee(employeeId, salary);
		
	}

	@Transactional
	@Override
	public void deleteEmployee(int employeeId) {
		employeeDAO.deleteEmployee(employeeId);
		
	}

	@Transactional
	@Override
	public Employee getEmployeeById(int employeeId) {
		// TODO Auto-generated method stub
		return  employeeDAO.getEmployeeById(employeeId);
	}

	@Transactional
	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployee();
	}

}
