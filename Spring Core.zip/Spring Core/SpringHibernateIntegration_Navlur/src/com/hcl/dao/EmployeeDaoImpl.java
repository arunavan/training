package com.hcl.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.hcl.entity.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public Integer addEmployee(Employee employee) {
		
		 Integer id =(Integer) hibernateTemplate.save(employee);
		return id;
	}

	@Override
	public void updateEmployee(Integer employeeId, Double salary) {
		
		Employee employee = hibernateTemplate.get(Employee.class,employeeId );
		if(employee!=null){
			employee.setSalary(salary);
			hibernateTemplate.update(employee);
					
		}
		
		
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		Employee employee = hibernateTemplate.load(Employee.class,employeeId );
		if(employee!=null){
			hibernateTemplate.delete(employee);
		}
		
	}

	@Override
	public Employee getEmployeeById(Integer employeeId) {
		Employee employee=null;
		employee = hibernateTemplate.get(Employee.class,employeeId );
		if(employee!=null){
			return employee;
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		return hibernateTemplate.loadAll(Employee.class);
	}
	
	
	

}
