package com.hcl.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.entity.Employee;
import com.hcl.service.EmployeeService;

public class AppTest {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
		EmployeeService service = (EmployeeService)context.getBean("employeeService");
		
		Employee employee = new Employee();
		employee.setEmployeeName("Joe");
		employee.setSalary(120000.00);
		
		//Integer id = service.addEmployee(employee);
		//System.out.println("Employee persisted successfully with Id "+id);
		
		//service.updateEmployee(81, 40000.00);
		
		//service.deleteEmployee(82);
		
		//Employee employee2 = service.getEmployeeById(81);
		//System.out.println(employee2.getEmployeeId()+"    "+employee2.getEmployeeName()+"    "+employee2.getSalary());
		
		List<Employee> elist = service.getAllEmployee();
		
		for(Employee emp:elist){
			System.out.println(emp.getEmployeeId()+"     "+emp.getEmployeeName()+"   "+emp.getSalary());
		}

	}

}
