package com.hcl.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.bean.Employee;
import com.hcl.service.EmployeeService;

public class AppTest2 {

	public static void main(String[] args) {
	
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring2.xml");
		EmployeeService service = (EmployeeService)context.getBean("employeeService");
		
		Employee employee = new Employee();
		employee.setEmployeeId(116);
		employee.setEmployeeName("Shewag");
		employee.setSalary(25000);

		service.addEmployee(employee);
		System.out.println("Data inserted successsfully");
		
		/*service.updateEmployee(101, 40000);
		System.out.println("Data updated successfully");*/
		
		/*service.deleteEmployee(103);
		System.out.println("Data deleted successfully");*/
		
		/*Employee employee1 = service.getEmployeeById(101);
		System.out.println("Employee Id "+employee1.getEmployeeId());
		System.out.println("Employee Name "+employee1.getEmployeeName());
		System.out.println("Salary "+employee1.getSalary() );*/
		
 	System.out.println("All employee Details");	
		List<Employee> empList = service.getAllEmployee();
		
		for (Employee employee2 : empList) {
			System.out.println(employee2.getEmployeeId()+"      "+employee2.getEmployeeName()+"      "+employee2.getSalary());
		}
		

	}

}
