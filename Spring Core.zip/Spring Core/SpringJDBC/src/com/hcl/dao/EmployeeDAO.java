package com.hcl.dao;

import java.util.List;

import com.hcl.bean.Employee;

public interface EmployeeDAO {
	
	public void addEmployee(Employee employee);
	public void updateEmployee(int employeeId, double salary);
	public void deleteEmployee(int employeeId);
	public Employee getEmployeeById(int employeeId);
	public List<Employee> getAllEmployee();
	
	

}
