package com.hcl.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.bean.Employee;

public class EmployeeMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
		Employee employee = new Employee();
		employee.setEmployeeId(rs.getInt("EMPLOYEEID"));
		employee.setEmployeeName(rs.getString("EMPLOYEENAME"));
		employee.setSalary(rs.getDouble("SALARY"));
		return employee;
	}

}
