package com.hcl.dao;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.bean.Employee;
@Repository(value="employeeDAO2")
public class EmployeeDAOImpl2 extends JdbcDaoSupport implements EmployeeDAO {
	
	
	//@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public void addEmployee(Employee employee) {
		int empId=employee.getEmployeeId();
		String empName= employee.getEmployeeName();
		double sal =employee.getSalary();
		String sql ="insert into employee values(?,?,?)";
		getJdbcTemplate().update(sql, empId,empName,sal);
	}

	@Override
	public void updateEmployee(int employeeId, double salary) {
		String sql = "update employee set salary=? where employeeId=?";
		getJdbcTemplate().update(sql, salary,employeeId);
		
	}

	@Override
	public void deleteEmployee(int employeeId) {
		String sql="delete from employee where employeeId =?";
		getJdbcTemplate().update(sql, employeeId);
		
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		String sql="select * from employee where employeeId=?";
		Employee employee =getJdbcTemplate().queryForObject(sql, new Object[]{employeeId}, new EmployeeMapper());
		return employee;
	
	}

	@Override
	public List<Employee> getAllEmployee() {
		String sql ="select * from employee";
		List<Employee> list = getJdbcTemplate().query(sql, new EmployeeMapper());
		return list;
		
	}

	
	
	

}
