package com.hcl.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.bean.Employee;
//@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public void addEmployee(Employee employee) {
		int empId=employee.getEmployeeId();
		String empName= employee.getEmployeeName();
		double sal =employee.getSalary();
		String sql ="insert into employee values(?,?,?)";
		jdbcTemplate.update(sql, empId,empName,sal);
	}

	@Override
	public void updateEmployee(int employeeId, double salary) {
		String sql = "update employee set salary=? where employeeId=?";
		jdbcTemplate.update(sql, salary,employeeId);
		
	}

	@Override
	public void deleteEmployee(int employeeId) {
		String sql="delete from employee where employeeId =?";
		jdbcTemplate.update(sql, employeeId);
		
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		String sql="select * from employee where employeeId=?";
		Employee employee =jdbcTemplate.queryForObject(sql, new Object[]{employeeId}, new EmployeeMapper());
		return employee;
	
	}

	@Override
	public List<Employee> getAllEmployee() {
		String sql ="select * from employee";
		List<Employee> list = jdbcTemplate.query(sql, new EmployeeMapper());
		return list;
		
	}

	
	
	

}
