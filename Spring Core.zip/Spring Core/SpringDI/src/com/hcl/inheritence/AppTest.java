package com.hcl.inheritence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("./com/hcl/inheritence/Beans.xml");
		
		SavingAccount savingAccount = (SavingAccount)context.getBean("saving");
		System.out.println(savingAccount.getBranchName());
		System.out.println(savingAccount.getBranchCode());
		System.out.println(savingAccount.getAccountType());

	}

}
