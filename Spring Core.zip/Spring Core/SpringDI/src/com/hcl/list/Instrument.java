package com.hcl.list;

public interface Instrument {

	void play();
}
