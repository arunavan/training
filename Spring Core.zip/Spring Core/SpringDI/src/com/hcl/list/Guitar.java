package com.hcl.list;

public class Guitar implements Instrument {

	@Override
	public void play() {
		
		System.out.println("TING TING TING");
		
	}

}
