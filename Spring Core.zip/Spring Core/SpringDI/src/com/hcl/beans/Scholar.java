package com.hcl.beans;

public class Scholar {
	
	private int  scholarId;
	private String scholarName;
	private Address address;
	
		
	public int getScholarId() {
		return scholarId;
	}
	public void setScholarId(int scholarId) {
		this.scholarId = scholarId;
	}
	public String getScholarName() {
		return scholarName;
	}
	public void setScholarName(String scholarName) {
		this.scholarName = scholarName;
	}
	
	public void displayScholarDetails(){
		System.out.println("scholar Id "+getScholarId());
		System.out.println("scholar Name "+getScholarName());
		//System.out.println("StreeNo  "+getAddress().getStreetNo());
		//System.out.println("StreetName "+getAddress().getStreetName());
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	
}
