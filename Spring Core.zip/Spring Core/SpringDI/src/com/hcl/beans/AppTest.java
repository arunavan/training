package com.hcl.beans;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTest {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext  context = new ClassPathXmlApplicationContext("Beans.xml");
		Scholar scholar = (Scholar) context.getBean("scholar");
		
		scholar.displayScholarDetails();

	}

}
