package com.hcl.beans;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private Address address;
	
	public  Employee(int employeeId,String employeeName, Address address ){
		this.employeeId= employeeId;
		this.employeeName=employeeName;
		this.address=address;
	}
	
	public void displayEmpDetails(){
		System.out.println("Employee Id "+employeeId);
		System.out.println("Employee Name "+employeeName);
		System.out.println("Street No "+address.getStreetNo());
		System.out.println("Street Name "+address.getStreetName());
	}

}
