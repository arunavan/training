package com.hcl.constructor;

public class Sitar implements Instrument{

	@Override
	public void play() {
		System.out.println("TONG TONG TONG");
		
	}

}
