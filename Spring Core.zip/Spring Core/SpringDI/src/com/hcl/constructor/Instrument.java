package com.hcl.constructor;

public interface Instrument {

	void play();
}
