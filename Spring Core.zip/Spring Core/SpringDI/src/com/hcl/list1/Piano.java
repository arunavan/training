package com.hcl.list1;

public class Piano implements Instrument {

	@Override
	public void play() {
		System.out.println("SA RE GA MA");
		
	}

}
