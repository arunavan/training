package com.hcl.list1;

public interface Instrument {

	void play();
}
