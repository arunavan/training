package com.hcl.list1;

public class Guitar implements Instrument {

	@Override
	public void play() {
		
		System.out.println("TING TING TING");
		
	}

}
