package com.hcl.list1;

public class Sitar implements Instrument{

	@Override
	public void play() {
		System.out.println("TONG TONG TONG");
		
	}

}
