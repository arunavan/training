package com.hcl.list1;

import java.util.List;

public class Performer {
	private String song;
	private List<Instrument> instruments;

	public Performer(List<Instrument>instruments){
		this.instruments=instruments;
	}
	

	public String getSong() {
		return song;
	}

	public void setSong(String song) {
		this.song = song;
	}
	
	public void perform(){
		System.out.println("Singing ......."+song);
		
		for(Instrument instrument: instruments){
			instrument.play();
		}
		
		
	}
	

}
