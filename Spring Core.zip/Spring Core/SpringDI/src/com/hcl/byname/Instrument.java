package com.hcl.byname;

public interface Instrument {

	void play();
}
