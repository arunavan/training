package com.hcl.byname;

public class Performer {
	private String song;
	private Instrument instrument;

	public Instrument getInstrument() {
		return instrument;
	}

	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}
	
	

	

	public String getSong() {
		return song;
	}

	public void setSong(String song) {
		this.song = song;
	}
	
	public void perform(){
		System.out.println("Singing ......."+song);
		instrument.play();
		
		
	}
	

}
