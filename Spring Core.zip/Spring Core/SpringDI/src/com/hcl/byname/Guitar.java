package com.hcl.byname;

public class Guitar implements Instrument {

	@Override
	public void play() {
		
		System.out.println("TING TING TING");
		
	}

}
