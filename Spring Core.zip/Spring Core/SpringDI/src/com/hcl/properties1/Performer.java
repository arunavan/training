package com.hcl.properties1;

import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class Performer {
	
	private String song;
	private Properties hibernateProperties;
	
	public String getSong() {
		return song;
	}
	public void setSong(String song) {
		this.song = song;
	}
	
	
	
	public Properties getHibernateProperties() {
		return hibernateProperties;
	}
	public void setHibernateProperties(Properties hibernateProperties) {
		this.hibernateProperties = hibernateProperties;
	}
	public void perform(){
		
		Set<Entry<Object, Object>> set = hibernateProperties.entrySet();
		for (Entry<Object, Object> entry : set) {
			System.out.println(entry.getKey()+"\t\t\t"+entry.getValue());
		}
		
	}
	

}
