package com.hcl.map;

public interface Instrument {

	void play();
}
