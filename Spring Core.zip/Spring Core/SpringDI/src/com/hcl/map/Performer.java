package com.hcl.map;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Performer {
	private String song;
	private Map<String, Instrument> instruments;

	public String getSong() {
		return song;
	}

	public void setSong(String song) {
		this.song = song;
	}

	public Map<String, Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(Map<String, Instrument> instruments) {
		this.instruments = instruments;
	}

	public void perform() {
		System.out.println("Singing ......." + song);
		
		 Set<Entry<String, Instrument>>  set = instruments.entrySet();
		 for(Entry<String, Instrument> entry: set){
			 System.out.print(entry.getKey()+"  ");
			 entry.getValue().play();
		 }

	}

}
