package com.hcl.autodetect;

public interface Instrument {

	void play();
}
