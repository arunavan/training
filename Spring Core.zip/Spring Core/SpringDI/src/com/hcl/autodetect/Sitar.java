package com.hcl.autodetect;

public class Sitar implements Instrument{

	@Override
	public void play() {
		System.out.println("TONG TONG TONG");
		
	}

}
