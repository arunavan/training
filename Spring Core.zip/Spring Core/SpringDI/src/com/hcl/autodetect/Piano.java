package com.hcl.autodetect;

public class Piano implements Instrument {

	@Override
	public void play() {
		System.out.println("SA RE GA MA");
		
	}

}
