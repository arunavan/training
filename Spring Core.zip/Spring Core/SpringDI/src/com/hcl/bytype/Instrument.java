package com.hcl.bytype;

public interface Instrument {

	void play();
}
