package com.hcl.bytype;

public class Guitar implements Instrument {

	@Override
	public void play() {
		
		System.out.println("TING TING TING");
		
	}

}
