package com.hcl.properties;

import java.util.Map;
import java.util.Properties;

public class Performer {
	private String song;
	private Properties  instruments;

	public String getSong() {
		return song;
	}

	public void setSong(String song) {
		this.song = song;
	}

	
	public Properties getInstruments() {
		return instruments;
	}

	public void setInstruments(Properties instruments) {
		this.instruments = instruments;
	}

	public void perform() {
		System.out.println("Singing ......." + song);
		
		for (Map.Entry<Object, Object> e : instruments.entrySet()) {
			  String key = (String) e.getKey();
			  String value = (String) e.getValue();
			  System.out.println(key+"     "+value);
			  
			}

	}

}
