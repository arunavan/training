package com.hcl.scopes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppTest {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("./com/hcl/scopes/Beans.xml");
		Calculate calculate =(Calculate)context.getBean("calculate");
		System.out.println("Initial Value");
		calculate.add();
		
		calculate.setNum1(100);
		calculate.setNum2(200);
		System.out.println("After setting the values");
		calculate.add();
		
		/*Calculate calculate2 = (Calculate)context.getBean("calculate");
		calculate2.add();*/
		
		context.registerShutdownHook();
		//context.close();
		
		calculate.add();

	}

}
