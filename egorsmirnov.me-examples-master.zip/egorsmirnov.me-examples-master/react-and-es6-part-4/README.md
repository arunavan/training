
React and ES6 - Part 4, React Mixins when using ES6 and React

Link to blog post - [React and ES6 - Part 4, React Mixins when using ES6 and React](http://egorsmirnov.me/2015/09/30/react-and-es6-part4.html).

## How to install

* Run `npm install`
* Run `gulp`
* Open index.html in your browser
