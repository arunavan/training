
React and ES6 - Part 2, React Classes and ES7 Property Initializers

Link to blog post - [React and ES6 - Part 2, React Classes and ES7 Property Initializers](http://egorsmirnov.me/2015/06/14/react-and-es6-part2.html).

## How to install

* Run `npm install`
* Run `gulp`
* Open index.html in your browser
