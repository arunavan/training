Babel 6 and Webpack

## How to install

* Run `npm install`
* Run `npm start`
* Open http://localhost:8080
