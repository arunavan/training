
React and ES6 - Part 6, React and ES6 Workflow with Webpack

Link to blog post - [React and ES6 - Part 6, React and ES6 Workflow with Webpack](http://egorsmirnov.me/).

## How to install

* Run `npm install`
* Run `npm start`
* Open `http://localhost:3000` in your browser
