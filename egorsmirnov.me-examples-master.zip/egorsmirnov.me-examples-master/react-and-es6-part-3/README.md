
React and ES6 - Part 3, Binding to methods of React class (ES7 included)

Link to blog post - [React and ES6 - Part 3, Binding to methods of React class (ES7 included)](http://egorsmirnov.me/2015/08/16/react-and-es6-part3.html).

## How to install

* Run `npm install`
* Run `gulp`
* Open index.html in your browser
