
React and ES6 - Part 5, React and ES6 Workflow with JSPM

Link to blog post - [React and ES6 - Part 5, React and ES6 Workflow with JSPM](http://egorsmirnov.me/2015/10/11/react-and-es6-part5.html).

## How to install

* Run `npm install -g jspm@0.16.12`
* Run `npm install`
* Open index.html in your browser
