
React and ES6 - Part1, Introduction. 

Link to blog post - [React and ES6 - Part 1, Introduction](http://egorsmirnov.me/2015/05/22/react-and-es6-part1.html).

## How to install

* Run `npm install`
* Run `gulp`
* Open index.html in your browser
