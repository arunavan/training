
Babel 6 and Babelify

## How to install

* Run `npm install`
* Run `gulp`
* Open index.html in your browser
